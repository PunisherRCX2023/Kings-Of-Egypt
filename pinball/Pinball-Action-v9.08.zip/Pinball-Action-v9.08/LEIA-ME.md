# Pinball Action V9.08

Arrancar: abrir `index.html` por servidor local (ex.: `python3 -m http.server`).
- `original-crt.html` → Original + CRT (modo `?mode=classic`)
- `hd2d.html` → 2D-HD (modo `?mode=hd`)
- Botão CRT / 2D-HD no jogo continua a alternar.

## assets/ (extraídos das ROMs gráficas, 1 PNG por peça)
background/ · ball/ · flippers/ · bumpers-tambores/ · barriers-guias/ · targets/ · lettering-display/ · characters-bonus/ · misc/
`manifest.json` indica atlas, índice e grupo de paleta; `palette-256.json` tem a paleta.
Nota: a classificação por peça é visual (feita à mão); 'misc' e alguns 'barriers-guias' precisam de confirmação.
Peças sem cor observada em jogo usam o grupo 12 por defeito (`palette_observed:false`).
Os assets ainda NÃO são carregados pelo motor: o jogo continua a descodificar as ROMs embebidas.

## Alterações V9.08
- Ficheiros consolidados (antes: index V9.04, game V8.28, v904, v907, 2 pixi-renderer).
- Mode por URL (`?mode=classic|hd`).
- Etiqueta do canto dizia sempre "2D-HD", mesmo em CRT; agora mostra o modo real.
- PixiJS: tenta `vendor/pixi.min.js` (offline) antes da CDN.
## Por corrigir
- Modo HD: manchas retangulares de cor a rodear peças (topo-esq., direita, canto inferior direito).
